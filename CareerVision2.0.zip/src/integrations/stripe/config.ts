export const STRIPE_CONFIG = {
  // Prices
  MONTHLY_PLAN_PRICE_ID: 'price_1RJumRJjRarA6eH84kygqd80',
  YEARLY_PLAN_PRICE_ID: 'price_1RJumvJjRarA6eH8KTvJCoGL',
  
  // Price amounts (for display)
  MONTHLY_PLAN_PRICE: 14.99,
  YEARLY_PLAN_PRICE: 129.99,
}; 